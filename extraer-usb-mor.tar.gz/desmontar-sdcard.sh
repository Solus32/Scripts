#!/bin/sh
echo
echo "\e[93mDesmontando Unidad"
echo "\e[0m"
udisksctl unmount -b /dev/sdc2
udisksctl unmount -b /dev/sdc1
echo
echo "\e[93mUnidad Desmontada"
echo

