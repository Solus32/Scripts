#!/bin/sh
echo
echo "\e[93mDesmontando Unidad"
echo "\e[0m"
sync
sleep 3
udisksctl unmount -b /dev/sdd2
udisksctl unmount -b /dev/sdd1
echo
echo "\e[93mUnidad Desmontada"
echo

