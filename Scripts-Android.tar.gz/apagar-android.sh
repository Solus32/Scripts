#!/bin/sh
adb shell reboot -p
