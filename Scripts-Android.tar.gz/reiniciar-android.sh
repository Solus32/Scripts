#!/bin/sh
adb shell reboot
