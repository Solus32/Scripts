#!/bin/sh
cd ~/Descargas
mv *.apk ~/Android/Apk
mv *.apkm ~/Android/Apk
mv *.xapk ~/Android/Apk
