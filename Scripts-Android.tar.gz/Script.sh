#!/bin/sh
sudo mv apagar-android.sh /usr/local/bin/apagar-android
sudo mv reiniciar-android.sh /usr/local/bin/reiniciar-android
sudo mv mover-apk.sh /usr/local/bin/mover-apk
sudo chmod +x /usr/local/bin/apagar-android
sudo chmod +x /usr/local/bin/reiniciar-android
sudo chmod +x /usr/local/bin/mover-apk
cd /usr/local/bin
sudo chown root:root *
