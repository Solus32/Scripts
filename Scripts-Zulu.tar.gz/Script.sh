#!/bin/sh
sudo mv Actualizar-Azul-Zulu.sh /usr/local/bin/actualizar-zulu
sudo mv Instalar-Azul-Zulu.sh /usr/local/bin/instalar-zulu
sudo mv Eliminar-Azul-Zulu.sh /usr/local/bin/eliminar-zulu
sudo chmod +x /usr/local/bin/actualizar-zulu
sudo chmod +x /usr/local/bin/instalar-zulu
sudo chmod +x /usr/local/bin/eliminar-zulu
cd /usr/local/bin
sudo chown root:root *
