#!/bin/sh
echo
echo "\e[93mSe instalará Zulu OpenJDK"
echo
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo apt purge default-jre default-jdk openjdk* icedtea* gcj*
sudo apt autoremove
echo
echo "\e[93mDescomprimiendo Azul Zulu OpenJDK"
echo "\e[0m"
cd ~/Descargas
tar -xvf zulu*-jdk*-linux_*.tar.gz
rm *.tar.gz
mv zulu*-jdk*-linux_* zulu-8
echo
echo "\e[93mCreando Directorio"
echo "\e[0m"
sudo mkdir -p /opt/Zulu
echo "\e[93mMoviendo Carpeta a /opt/Zulu/zulu-8"
echo "\e[0m"
sudo mv zulu-8 /opt/Zulu
sudo chown -R root:root /opt/Zulu/zulu-8
echo "\e[93mActualizando Alternativas de Java"
echo "\e[0m"
sudo update-alternatives --install '/usr/bin/appletviewer' 'appletviewer' '/opt/Zulu/zulu-8/bin/appletviewer' 1
sudo update-alternatives --install '/usr/bin/extcheck' 'extcheck' '/opt/Zulu/zulu-8/bin/extcheck' 1
sudo update-alternatives --install '/usr/bin/idlj' 'idlj' '/opt/Zulu/zulu-8/bin/idlj' 1
sudo update-alternatives --install '/usr/bin/jar' 'jar' '/opt/Zulu/zulu-8/bin/jar' 1
sudo update-alternatives --install '/usr/bin/jarsigner' 'jarsigner' '/opt/Zulu/zulu-8/bin/jarsigner' 1
sudo update-alternatives --install '/usr/bin/java' 'java' '/opt/Zulu/zulu-8/bin/java' 1
sudo update-alternatives --install '/usr/bin/javac' 'javac' '/opt/Zulu/zulu-8/bin/javac' 1
sudo update-alternatives --install '/usr/bin/javadoc' 'javadoc' '/opt/Zulu/zulu-8/bin/javadoc' 1
sudo update-alternatives --install '/usr/bin/javah' 'javah' '/opt/Zulu/zulu-8/bin/javah' 1
sudo update-alternatives --install '/usr/bin/javap' 'javap' '/opt/Zulu/zulu-8/bin/javap' 1
sudo update-alternatives --install '/usr/bin/jcmd' 'jcmd' '/opt/Zulu/zulu-8/bin/jcmd' 1
sudo update-alternatives --install '/usr/bin/jconsole' 'jconsole' '/opt/Zulu/zulu-8/bin/jconsole' 1
sudo update-alternatives --install '/usr/bin/jdb' 'jdb' '/opt/Zulu/zulu-8/bin/jdb' 1
sudo update-alternatives --install '/usr/bin/jdeps' 'jdeps' '/opt/Zulu/zulu-8/bin/jdeps' 1
sudo update-alternatives --install '/usr/bin/jhat' 'jhat' '/opt/Zulu/zulu-8/bin/jhat' 1
sudo update-alternatives --install '/usr/bin/jinfo' 'jinfo' '/opt/Zulu/zulu-8/bin/jinfo' 1
sudo update-alternatives --install '/usr/bin/jjs' 'jjs' '/opt/Zulu/zulu-8/bin/jjs' 1
sudo update-alternatives --install '/usr/bin/jmap' 'jmap' '/opt/Zulu/zulu-8/bin/jmap' 1
sudo update-alternatives --install '/usr/bin/jps' 'jps' '/opt/Zulu/zulu-8/bin/jps' 1
sudo update-alternatives --install '/usr/bin/jrunscript' 'jrunscript' '/opt/Zulu/zulu-8/bin/jrunscript' 1
sudo update-alternatives --install '/usr/bin/jsadebugd' 'jsadebugd' '/opt/Zulu/zulu-8/bin/jsadebugd' 1
sudo update-alternatives --install '/usr/bin/jstack' 'jstack' '/opt/Zulu/zulu-8/bin/jstack' 1
sudo update-alternatives --install '/usr/bin/jstat' 'jstat' '/opt/Zulu/zulu-8/bin/jstat' 1
sudo update-alternatives --install '/usr/bin/jstatd' 'jstatd' '/opt/Zulu/zulu-8/bin/jstatd' 1
sudo update-alternatives --install '/usr/bin/keytool' 'keytool' '/opt/Zulu/zulu-8/bin/keytool' 1
sudo update-alternatives --install '/usr/bin/native2ascii' 'native2ascii' '/opt/Zulu/zulu-8/bin/native2ascii' 1
sudo update-alternatives --install '/usr/bin/orbd' 'orbd' '/opt/Zulu/zulu-8/bin/orbd' 1
sudo update-alternatives --install '/usr/bin/pack200' 'pack200' '/opt/Zulu/zulu-8/bin/pack200' 1
sudo update-alternatives --install '/usr/bin/policytool' 'policytool' '/opt/Zulu/zulu-8/bin/policytool' 1
sudo update-alternatives --install '/usr/bin/rmic' 'rmic' '/opt/Zulu/zulu-8/bin/rmic' 1
sudo update-alternatives --install '/usr/bin/rmid' 'rmid' '/opt/Zulu/zulu-8/bin/rmid' 1
sudo update-alternatives --install '/usr/bin/rmiregistry' 'rmiregistry' '/opt/Zulu/zulu-8/bin/rmiregistry' 1
sudo update-alternatives --install '/usr/bin/schemagen' 'schemagen' '/opt/Zulu/zulu-8/bin/schemagen' 1
sudo update-alternatives --install '/usr/bin/serialver' 'serialver' '/opt/Zulu/zulu-8/bin/serialver' 1
sudo update-alternatives --install '/usr/bin/servertool' 'servertool' '/opt/Zulu/zulu-8/bin/servertool' 1
sudo update-alternatives --install '/usr/bin/tnameserv' 'tnameserv' '/opt/Zulu/zulu-8/bin/tnameserv' 1
sudo update-alternatives --install '/usr/bin/unpack200' 'unpack200' '/opt/Zulu/zulu-8/bin/unpack200' 1
sudo update-alternatives --install '/usr/bin/wsgen' 'wsgen' '/opt/Zulu/zulu-8/bin/wsgen' 1
sudo update-alternatives --install '/usr/bin/wsimport' 'wsimport' '/opt/Zulu/zulu-8/bin/wsimport' 1
sudo update-alternatives --install '/usr/bin/xjc' 'xjc' '/opt/Zulu/zulu-8/bin/xjc' 1
echo
echo "\e[93mActualizando Base de Datos"
echo "\e[0m"
sudo updatedb
echo
echo "\e[93mInstalación de Zulu OpenJDK finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo
