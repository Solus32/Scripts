#!/bin/sh
echo
echo "\e[93mSe Eliminará Zulu OpenJDK"
echo
echo "\e[93mEliminando Zulu OpenJDK"
echo
echo "\e[93mEliminando Alternativas de Java"
echo
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo update-alternatives --remove appletviewer /opt/Zulu/zulu-8/bin/appletviewer 
sudo update-alternatives --remove extcheck /opt/Zulu/zulu-8/bin/extcheck
sudo update-alternatives --remove idlj /opt/Zulu/zulu-8/bin/idlj
sudo update-alternatives --remove jar /opt/Zulu/zulu-8/bin/jar
sudo update-alternatives --remove jarsigner /opt/Zulu/zulu-8/bin/jarsigner
sudo update-alternatives --remove java /opt/Zulu/zulu-8/bin/java
sudo update-alternatives --remove javac /opt/Zulu/zulu-8/bin/javac
sudo update-alternatives --remove javadoc /opt/Zulu/zulu-8/bin/javadoc
sudo update-alternatives --remove javah /opt/Zulu/zulu-8/bin/javah
sudo update-alternatives --remove javap /opt/Zulu/zulu-8/bin/javap
sudo update-alternatives --remove jcmd /opt/Zulu/zulu-8/bin/jcmd
sudo update-alternatives --remove jconsole /opt/Zulu/zulu-8/bin/jconsole
sudo update-alternatives --remove jdb /opt/Zulu/zulu-8/bin/jdb
sudo update-alternatives --remove jdeps /opt/Zulu/zulu-8/bin/jdeps
sudo update-alternatives --remove jhat /opt/Zulu/zulu-8/bin/jhat
sudo update-alternatives --remove jinfo /opt/Zulu/zulu-8/bin/jinfo
sudo update-alternatives --remove jjs /opt/Zulu/zulu-8/bin/jjs
sudo update-alternatives --remove jmap /opt/Zulu/zulu-8/bin/jmap
sudo update-alternatives --remove jps /opt/Zulu/zulu-8/bin/jps
sudo update-alternatives --remove jrunscript /opt/Zulu/zulu-8/bin/jrunscript
sudo update-alternatives --remove jsadebugd /opt/Zulu/zulu-8/bin/jsadebugd
sudo update-alternatives --remove jstack /opt/Zulu/zulu-8/bin/jstack
sudo update-alternatives --remove jstat /opt/Zulu/zulu-8/bin/jstat
sudo update-alternatives --remove jstatd /opt/Zulu/zulu-8/bin/jstatd
sudo update-alternatives --remove keytool /opt/Zulu/zulu-8/bin/keytool
sudo update-alternatives --remove native2ascii /opt/Zulu/zulu-8/bin/native2ascii
sudo update-alternatives --remove orbd /opt/Zulu/zulu-8/bin/orbd
sudo update-alternatives --remove pack200 /opt/Zulu/zulu-8/bin/pack200
sudo update-alternatives --remove policytool /opt/Zulu/zulu-8/bin/policytool
sudo update-alternatives --remove rmic /opt/Zulu/zulu-8/bin/rmic
sudo update-alternatives --remove rmid /opt/Zulu/zulu-8/bin/rmid
sudo update-alternatives --remove rmiregistry /opt/Zulu/zulu-8/bin/rmiregistry
sudo update-alternatives --remove schemagen /opt/Zulu/zulu-8/bin/schemagen
sudo update-alternatives --remove serialver /opt/Zulu/zulu-8/bin/serialver
sudo update-alternatives --remove servertool /opt/Zulu/zulu-8/bin/servertool
sudo update-alternatives --remove tnameserv /opt/Zulu/zulu-8/bin/tnameserv
sudo update-alternatives --remove unpack200 /opt/Zulu/zulu-8/bin/unpack200
sudo update-alternatives --remove wsgen /opt/Zulu/zulu-8/bin/wsgen
sudo update-alternatives --remove wsimport /opt/Zulu/zulu-8/bin/wsimport
sudo update-alternatives --remove xjc /opt/Zulu/zulu-8/bin/xjc
echo
echo "\e[93mEliminando Directorio"
echo "\e[0m"
sudo rm -r -f /opt/Zulu
echo "\e[93mEliminando Enlaces de Zulu OpenJDK"
echo
echo "\e[93mActualizando Base de Datos"
echo "\e[0m"
sudo updatedb
echo
echo "\e[93mEliminación de Zulu OpenJDK finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo
