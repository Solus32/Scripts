#!/bin/sh
echo "Se Actualizara Azul Zulu OpenJDK"
echo "Descomprimiendo Azul Zulu OpenJDK"
cd ~/Descargas
tar -xvf zulu*-jdk*-linux_*.tar.gz
rm *.tar.gz
sudo rm -r -f /opt/Zulu/zulu-8
echo "Se requiere permisos root. Teclee su Contraseña."
echo "Actualizando Directorio"
mv zulu*-jdk*-linux_* zulu-8
echo "Moviendo Carpeta a /opt/Zulu/zulu-8"
sudo mv zulu-8 /opt/Zulu
sudo chown -R root:root /opt/Zulu/zulu-8
echo "Actualizacion de Azul Zulu OpenJDK finalizada"
echo "Que tengas un bonito dia"



