#!/bin/sh
echo
echo "\e[93mSe Actualizará Zulu OpenJDK"
echo
echo "\e[93mDescomprimiendo Zulu OpenJDK"
echo "\e[0m"
cd ~/Descargas
tar -xvf zulu*.tar.gz
rm zulu*.tar.gz
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo rm -r -f /opt/Zulu/zulu-8
echo "\e[93mActualizando Directorio"
echo "\e[0m"
mv zulu* zulu-8
echo "\e[93mMoviendo Carpeta a /opt/Zulu/zulu-8"
echo "\e[0m"
sudo mv zulu-8 /opt/Zulu
sudo chown -R root:root /opt/Zulu/zulu-8
echo "\e[93mActualización de Zulu OpenJDK finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo



