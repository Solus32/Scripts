#!/bin/sh
echo ""
echo "Desmontando Unidad"
echo ""
sudo udisksctl unmount -b /dev/sdd1
sleep 5
sudo udisksctl power-off -b /dev/sdd
echo ""
echo "Ya puedes extraer la unidad de forma segura"
echo ""
