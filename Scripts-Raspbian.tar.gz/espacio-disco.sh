#!/bin/bash

DISKSPACE=`df -kh /home/pi/ | tail -1 | tr -s ' ' | cut -d' ' -f4`
echo ""
echo "Tienes $DISKSPACE disponibles en tu Tarjeta SD."
echo ""
if [ -d "/home/pi/" ]; then
EXP_DISKSPACE=`df -kh /mnt/torrents/ | tail -1 | tr -s ' ' | cut -d' ' -f4`
echo ""
echo "Tienes $EXP_DISKSPACE disponibles en tu Unidad Externa."
echo ""
fi
exit
