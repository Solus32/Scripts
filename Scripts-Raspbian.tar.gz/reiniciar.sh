#!/bin/sh
sudo reboot