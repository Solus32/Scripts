#!/bin/sh
echo
echo "\e[93mSe Reiniciará la Raspberry Pi en 3 Segundos"
echo "\e[0m"
sleep 3
systemctl reboot
