#!/bin/sh
sudo shutdown -h now