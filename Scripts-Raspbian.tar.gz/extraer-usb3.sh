#!/bin/sh
echo
echo "\e[93mDesmontando Unidad"
echo "\e[0m"
sudo udisksctl unmount -b /dev/sdc1
sleep 5
sudo udisksctl power-off -b /dev/sdc
echo
echo "\e[93mYa puedes extraer la unidad de forma segura"
echo
