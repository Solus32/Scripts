#!/bin/sh
grep --color "UFW BLOCK" /var/log/syslog
