#!/bin/sh
sudo apt update
sudo apt full-upgrade
