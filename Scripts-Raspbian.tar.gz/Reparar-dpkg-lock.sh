#!/bin/sh
sudo rm /var/lib/dpkg/lock
