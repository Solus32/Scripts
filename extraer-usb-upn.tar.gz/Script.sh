#!/bin/sh
sudo mv extraer-usb.sh /usr/local/bin/extraer-usb
sudo mv extraer-usb2.sh /usr/local/bin/extraer-usb2
sudo mv extraer-usb3.sh /usr/local/bin/extraer-usb3
sudo mv extraer-usb4.sh /usr/local/bin/extraer-usb4
sudo mv extraer-sdcard.sh /usr/local/bin/extraer-sdcard
sudo mv extraer-sdcard2.sh /usr/local/bin/extraer-sdcard2
sudo mv desmontar-sdcard.sh /usr/local/bin/desmontar-sdcard
sudo mv desmontar-sdcard2.sh /usr/local/bin/desmontar-sdcard2
sudo mv apagar-sdcard.sh /usr/local/bin/apagar-sdcard
sudo mv apagar-sdcard2.sh /usr/local/bin/apagar-sdcard2
sudo chmod +x /usr/local/bin/extraer-usb
sudo chmod +x /usr/local/bin/extraer-usb2
sudo chmod +x /usr/local/bin/extraer-usb3
sudo chmod +x /usr/local/bin/extraer-usb4
sudo chmod +x /usr/local/bin/extraer-sdcard
sudo chmod +x /usr/local/bin/extraer-sdcard2
sudo chmod +x /usr/local/bin/desmontar-sdcard
sudo chmod +x /usr/local/bin/desmontar-sdcard2
sudo chmod +x /usr/local/bin/apagar-sdcard
sudo chmod +x /usr/local/bin/apagar-sdcard2
cd /usr/local/bin
sudo chown root:root *
