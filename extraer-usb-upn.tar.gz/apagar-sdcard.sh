#!/bin/sh
echo 
echo "\e[93mApagando Unidad"
echo "\e[0m"
sleep 5
udisksctl power-off -b /dev/sdd
echo 
echo "\e[93mYa puedes extraer la unidad de forma segura"
echo "\e[0m"
