#!/bin/sh
echo 
echo "\e[93mDesmontando Unidad"
echo "\e[0m"
echo 
udisksctl unmount -b /dev/sdf1
sleep 5
udisksctl power-off -b /dev/sdf
echo 
echo "\e[93mYa puedes extraer la unidad de forma segura"
echo "\e[0m"
