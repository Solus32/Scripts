#!/bin/sh
echo
echo "\e[93mSe Limpiará el Sistema, de las Actualizaciones Remanentes"
echo "\e[0m"
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo apt clean
sudo apt autoclean
echo
echo "\e[93mLimpieza Terminada"
echo
