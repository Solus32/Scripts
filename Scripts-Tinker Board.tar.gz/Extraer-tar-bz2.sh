#!/bin/sh
tar -xvjf *.tar.bz2
