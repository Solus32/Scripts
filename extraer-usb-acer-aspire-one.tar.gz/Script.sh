#!/bin/sh
sudo mv extraer-usb.sh /usr/local/bin/extraer-usb
sudo mv extraer-usb2.sh /usr/local/bin/extraer-usb2
sudo mv extraer-usb3.sh /usr/local/bin/extraer-usb3
sudo mv extraer-sdcard.sh /usr/local/bin/extraer-sdcard
sudo chmod +x /usr/local/bin/extraer-usb
sudo chmod +x /usr/local/bin/extraer-usb2
sudo chmod +x /usr/local/bin/extraer-usb3
sudo chmod +x /usr/local/bin/extraer-sdcard
cd /usr/local/bin
sudo chown root:root *

