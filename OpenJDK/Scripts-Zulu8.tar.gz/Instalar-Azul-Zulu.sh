#!/bin/sh
echo
echo "\e[93mSe instalará Azul Zulu OpenJDK"
echo
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo apt purge default-jre default-jdk openjdk* icedtea* gcj*
sudo apt autoremove
echo "\e[93mDescomprimiendo Azul Zulu OpenJDK"
echo "\e[0m"
cd ~/Descargas
tar -xvf zulu*.tar.gz
rm zulu*.tar.gz
mv zulu* zulu
echo
echo "\e[93mCreando Directorio"
echo "\e[0m"
sudo mkdir -p /opt
echo "\e[93mMoviendo Carpeta a /opt/zulu"
echo "\e[0m"
sudo mv zulu /opt
sudo chown -R root:root /opt/zulu
echo "\e[93mActualizando Alternativas de Java"
echo "\e[0m"
sudo update-alternatives --install '/usr/bin/appletviewer' 'appletviewer' '/opt/zulu/bin/appletviewer' 1
sudo update-alternatives --install '/usr/bin/clhsdb' 'clhsdb' '/opt/zulu/bin/clhsdb' 1
sudo update-alternatives --install '/usr/bin/extcheck' 'extcheck' '/opt/zulu/bin/extcheck' 1
sudo update-alternatives --install '/usr/bin/hsdb' 'hsdb' '/opt/zulu/bin/hsdb' 1
sudo update-alternatives --install '/usr/bin/idlj' 'idlj' '/opt/zulu/bin/idlj' 1
sudo update-alternatives --install '/usr/bin/jar' 'jar' '/opt/zulu/bin/jar' 1
sudo update-alternatives --install '/usr/bin/jarsigner' 'jarsigner' '/opt/zulu/bin/jarsigner' 1
sudo update-alternatives --install '/usr/bin/java' 'java' '/opt/zulu/bin/java' 1
sudo update-alternatives --install '/usr/bin/javac' 'javac' '/opt/zulu/bin/javac' 1
sudo update-alternatives --install '/usr/bin/javadoc' 'javadoc' '/opt/zulu/bin/javadoc' 1
sudo update-alternatives --install '/usr/bin/javah' 'javah' '/opt/zulu/bin/javah' 1
sudo update-alternatives --install '/usr/bin/javap' 'javap' '/opt/zulu/bin/javap' 1
sudo update-alternatives --install '/usr/bin/java-rmi.cgi' 'java-rmi.cgi' '/opt/zulu/bin/java-rmi.cgi' 1
sudo update-alternatives --install '/usr/bin/jcmd' 'jcmd' '/opt/zulu/bin/jcmd' 1
sudo update-alternatives --install '/usr/bin/jconsole' 'jconsole' '/opt/zulu/bin/jconsole' 1
sudo update-alternatives --install '/usr/bin/jdb' 'jdb' '/opt/zulu/bin/jdb' 1
sudo update-alternatives --install '/usr/bin/jdeps' 'jdeps' '/opt/zulu/bin/jdeps' 1
sudo update-alternatives --install '/usr/bin/jfr' 'jfr' '/opt/zulu/bin/jfr' 1
sudo update-alternatives --install '/usr/bin/jhat' 'jhat' '/opt/zulu/bin/jhat' 1
sudo update-alternatives --install '/usr/bin/jinfo' 'jinfo' '/opt/zulu/bin/jinfo' 1
sudo update-alternatives --install '/usr/bin/jjs' 'jjs' '/opt/zulu/bin/jjs' 1
sudo update-alternatives --install '/usr/bin/jmap' 'jmap' '/opt/zulu/bin/jmap' 1
sudo update-alternatives --install '/usr/bin/jps' 'jps' '/opt/zulu/bin/jps' 1
sudo update-alternatives --install '/usr/bin/jrunscript' 'jrunscript' '/opt/zulu/bin/jrunscript' 1
sudo update-alternatives --install '/usr/bin/jsadebugd' 'jsadebugd' '/opt/zulu/bin/jsadebugd' 1
sudo update-alternatives --install '/usr/bin/jstack' 'jstack' '/opt/zulu/bin/jstack' 1
sudo update-alternatives --install '/usr/bin/jstat' 'jstat' '/opt/zulu/bin/jstat' 1
sudo update-alternatives --install '/usr/bin/jstatd' 'jstatd' '/opt/zulu/bin/jstatd' 1
sudo update-alternatives --install '/usr/bin/keytool' 'keytool' '/opt/zulu/bin/keytool' 1
sudo update-alternatives --install '/usr/bin/native2ascii' 'native2ascii' '/opt/zulu/bin/native2ascii' 1
sudo update-alternatives --install '/usr/bin/orbd' 'orbd' '/opt/zulu/bin/orbd' 1
sudo update-alternatives --install '/usr/bin/pack200' 'pack200' '/opt/zulu/bin/pack200' 1
sudo update-alternatives --install '/usr/bin/policytool' 'policytool' '/opt/zulu/bin/policytool' 1
sudo update-alternatives --install '/usr/bin/rmic' 'rmic' '/opt/zulu/bin/rmic' 1
sudo update-alternatives --install '/usr/bin/rmid' 'rmid' '/opt/zulu/bin/rmid' 1
sudo update-alternatives --install '/usr/bin/rmiregistry' 'rmiregistry' '/opt/zulu/bin/rmiregistry' 1
sudo update-alternatives --install '/usr/bin/schemagen' 'schemagen' '/opt/zulu/bin/schemagen' 1
sudo update-alternatives --install '/usr/bin/serialver' 'serialver' '/opt/zulu/bin/serialver' 1
sudo update-alternatives --install '/usr/bin/servertool' 'servertool' '/opt/zulu/bin/servertool' 1
sudo update-alternatives --install '/usr/bin/tnameserv' 'tnameserv' '/opt/zulu/bin/tnameserv' 1
sudo update-alternatives --install '/usr/bin/unpack200' 'unpack200' '/opt/zulu/bin/unpack200' 1
sudo update-alternatives --install '/usr/bin/wsgen' 'wsgen' '/opt/zulu/bin/wsgen' 1
sudo update-alternatives --install '/usr/bin/wsimport' 'wsimport' '/opt/zulu/bin/wsimport' 1
sudo update-alternatives --install '/usr/bin/xjc' 'xjc' '/opt/zulu/bin/xjc' 1
echo
echo "\e[93mActualizando Base de Datos"
echo "\e[0m"
sudo updatedb
echo "\e[93mInstalación de Azul Zulu OpenJDK finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo
