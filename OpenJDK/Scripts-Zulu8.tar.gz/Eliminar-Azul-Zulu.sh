#!/bin/sh
echo
echo "\e[93mSe Eliminará Azul Zulu OpenJDK"
echo
echo "\e[93mEliminando Azul Zulu OpenJDK"
echo
echo "\e[93mEliminando Alternativas de Java"
echo
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo update-alternatives --remove appletviewer /opt/zulu/bin/appletviewer
sudo update-alternatives --remove clhsdb /opt/zulu/bin/clhsdb
sudo update-alternatives --remove extcheck /opt/zulu/bin/extcheck
sudo update-alternatives --remove hsdb /opt/zulu/bin/hsdb
sudo update-alternatives --remove idlj /opt/zulu/bin/idlj
sudo update-alternatives --remove jar /opt/zulu/bin/jar
sudo update-alternatives --remove jarsigner /opt/zulu/bin/jarsigner
sudo update-alternatives --remove java /opt/zulu/bin/java
sudo update-alternatives --remove javac /opt/zulu/bin/javac
sudo update-alternatives --remove javadoc /opt/zulu/bin/javadoc
sudo update-alternatives --remove javah /opt/zulu/bin/javah
sudo update-alternatives --remove javap /opt/zulu/bin/javap
sudo update-alternatives --remove java-rmi.cgi /opt/zulu/bin/java-rmi.cgi
sudo update-alternatives --remove jcmd /opt/zulu/bin/jcmd
sudo update-alternatives --remove jconsole /opt/zulu/bin/jconsole
sudo update-alternatives --remove jdb /opt/zulu/bin/jdb
sudo update-alternatives --remove jdeps /opt/zulu/bin/jdeps
sudo update-alternatives --remove jfr /opt/zulu/bin/jfr
sudo update-alternatives --remove jhat /opt/zulu/bin/jhat
sudo update-alternatives --remove jinfo /opt/zulu/bin/jinfo
sudo update-alternatives --remove jjs /opt/zulu/bin/jjs
sudo update-alternatives --remove jmap /opt/zulu/bin/jmap
sudo update-alternatives --remove jps /opt/zulu/bin/jps
sudo update-alternatives --remove jrunscript /opt/zulu/bin/jrunscript
sudo update-alternatives --remove jsadebugd /opt/zulu/bin/jsadebugd
sudo update-alternatives --remove jstack /opt/zulu/bin/jstack
sudo update-alternatives --remove jstat /opt/zulu/bin/jstat
sudo update-alternatives --remove jstatd /opt/zulu/bin/jstatd
sudo update-alternatives --remove keytool /opt/zulu/bin/keytool
sudo update-alternatives --remove native2ascii /opt/zulu/bin/native2ascii
sudo update-alternatives --remove orbd /opt/zulu/bin/orbd
sudo update-alternatives --remove pack200 /opt/zulu/bin/pack200
sudo update-alternatives --remove policytool /opt/zulu/bin/policytool
sudo update-alternatives --remove rmic /opt/zulu/bin/rmic
sudo update-alternatives --remove rmid /opt/zulu/bin/rmid
sudo update-alternatives --remove rmiregistry /opt/zulu/bin/rmiregistry
sudo update-alternatives --remove schemagen /opt/zulu/bin/schemagen
sudo update-alternatives --remove serialver /opt/zulu/bin/serialver
sudo update-alternatives --remove servertool /opt/zulu/bin/servertool
sudo update-alternatives --remove tnameserv /opt/zulu/bin/tnameserv
sudo update-alternatives --remove unpack200 /opt/zulu/bin/unpack200
sudo update-alternatives --remove wsgen /opt/zulu/bin/wsgen
sudo update-alternatives --remove wsimport /opt/zulu/bin/wsimport
sudo update-alternatives --remove xjc /opt/zulu/bin/xjc
echo
echo "\e[93mEliminando Directorio"
echo "\e[0m"
sudo rm -r -f /opt/zulu
echo "\e[93mEliminando Enlaces de Azul Zulu OpenJDK"
echo
echo "\e[93mActualizando Base de Datos"
echo "\e[0m"
sudo updatedb
echo "\e[93mEliminación de Azul Zulu OpenJDK finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo
