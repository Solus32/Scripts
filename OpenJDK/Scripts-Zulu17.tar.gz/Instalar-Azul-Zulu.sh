#!/bin/sh
echo "\e[93mSe instalara Azul Zulu OpenJDK"
sudo apt purge default-jre default-jdk openjdk* icedtea* gcj*
sudo apt autoremove
echo "\e[93mDescomprimiendo Azul Zulu OpenJDK"
echo "\e[0m"
cd ~/Descargas
tar -xvf zulu*.tar.gz
rm zulu*.tar.gz
mv zulu*-jdk*-linux_* zulu
echo "\e[91mSe requiere permisos root. Teclee su Contraseña."
echo "\e[93mCreando Directorio"
sudo mkdir -p /opt
echo "\e[93mMoviendo Carpeta a /opt/zulu"
echo "\e[0m"
sudo mv zulu /opt
sudo chown -R root:root /opt/zulu
echo "\e[93mActualizando Alternativas de Java"
echo "\e[0m"
sudo update-alternatives --install '/usr/bin/jar' 'jar' '/opt/zulu/bin/jar' 1
sudo update-alternatives --install '/usr/bin/jarsigner' 'jarsigner' '/opt/zulu/bin/jarsigner' 1
sudo update-alternatives --install '/usr/bin/java' 'java' '/opt/zulu/bin/java' 1
sudo update-alternatives --install '/usr/bin/javac' 'javac' '/opt/zulu/bin/javac' 1
sudo update-alternatives --install '/usr/bin/javadoc' 'javadoc' '/opt/zulu/bin/javadoc' 1
sudo update-alternatives --install '/usr/bin/javap' 'javap' '/opt/zulu/bin/javap' 1
sudo update-alternatives --install '/usr/bin/jcmd' 'jcmd' '/opt/zulu/bin/jcmd' 1
sudo update-alternatives --install '/usr/bin/jconsole' 'jconsole' '/opt/zulu/bin/jconsole' 1
sudo update-alternatives --install '/usr/bin/jdb' 'jdb' '/opt/zulu/bin/jdb' 1
sudo update-alternatives --install '/usr/bin/jdeprscan' 'jdeprscan' '/opt/zulu/bin/jdeprscan' 1
sudo update-alternatives --install '/usr/bin/jdeps' 'jdeps' '/opt/zulu/bin/jdeps' 1
sudo update-alternatives --install '/usr/bin/jfr' 'jfr' '/opt/zulu/bin/jfr' 1
sudo update-alternatives --install '/usr/bin/jhsdb' 'jhsdb' '/opt/zulu/bin/jhsdb' 1
sudo update-alternatives --install '/usr/bin/jimage' 'jimage' '/opt/zulu/bin/jimage' 1
sudo update-alternatives --install '/usr/bin/jinfo' 'jinfo' '/opt/zulu/bin/jinfo' 1
sudo update-alternatives --install '/usr/bin/jlink' 'jlink' '/opt/zulu/bin/jlink' 1
sudo update-alternatives --install '/usr/bin/jmap' 'jmap' '/opt/zulu/bin/jmap' 1
sudo update-alternatives --install '/usr/bin/jmod' 'jmod' '/opt/zulu/bin/jmod' 1
sudo update-alternatives --install '/usr/bin/jpackage' 'jpackage' '/opt/zulu/bin/jpackage' 1
sudo update-alternatives --install '/usr/bin/jps' 'jps' '/opt/zulu/bin/jps' 1
sudo update-alternatives --install '/usr/bin/jrunscript' 'jrunscript' '/opt/zulu/bin/jrunscript' 1
sudo update-alternatives --install '/usr/bin/jshell' 'jshell' '/opt/zulu/bin/jshell' 1
sudo update-alternatives --install '/usr/bin/jstack' 'jstack' '/opt/zulu/bin/jstack' 1
sudo update-alternatives --install '/usr/bin/jstat' 'jstat' '/opt/zulu/bin/jstat' 1
sudo update-alternatives --install '/usr/bin/jstatd' 'jstatd' '/opt/zulu/bin/jstatd' 1
sudo update-alternatives --install '/usr/bin/keytool' 'keytool' '/opt/zulu/bin/keytool' 1
sudo update-alternatives --install '/usr/bin/rmiregistry' 'rmiregistry' '/opt/zulu/bin/rmiregistry' 1
sudo update-alternatives --install '/usr/bin/serialver' 'serialver' '/opt/zulu/bin/serialver' 1
echo "\e[93mActualizando Base de Datos"
echo "\e[0m"
sudo updatedb
echo "\e[93mInstalacion de Azul Zulu OpenJDK finalizada"
echo "\e[93mQue tengas un bonito dia"
echo "\e[0m"
