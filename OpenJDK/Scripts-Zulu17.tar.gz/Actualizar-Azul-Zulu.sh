#!/bin/sh
echo
echo "\e[93mSe Actualizará Azul Zulu OpenJDK"
echo
echo "\e[93mDescomprimiendo Azul Zulu OpenJDK"
echo "\e[0m"
cd ~/Descargas
tar -xvf zulu*.tar.gz
rm zulu*.tar.gz
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo rm -r -f /opt/zulu
echo "\e[93mActualizando Directorio"
echo "\e[0m"
mv zulu* zulu
echo "\e[93mMoviendo Carpeta a /opt/zulu"
echo "\e[0m"
sudo mv zulu /opt
sudo chown -R root:root /opt/zulu
echo "\e[93mActualización de Azul Zulu OpenJDK finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo
