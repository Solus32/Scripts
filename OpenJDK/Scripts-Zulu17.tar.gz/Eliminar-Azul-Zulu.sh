#!/bin/sh
echo
echo "\e[93mSe Eliminará Azul Zulu OpenJDK"
echo
echo "\e[93mEliminando Azul Zulu OpenJDK"
echo
echo "\e[93mEliminando Alternativas de Java"
echo
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo update-alternatives --remove jar /opt/zulu/bin/jar
sudo update-alternatives --remove jarsigner /opt/zulu/bin/jarsigner
sudo update-alternatives --remove java /opt/zulu/bin/java
sudo update-alternatives --remove javac /opt/zulu/bin/javac
sudo update-alternatives --remove javadoc /opt/zulu/bin/javadoc
sudo update-alternatives --remove javap /opt/zulu/bin/javap
sudo update-alternatives --remove jcmd /opt/zulu/bin/jcmd
sudo update-alternatives --remove jconsole /opt/zulu/bin/jconsole
sudo update-alternatives --remove jdb /opt/zulu/bin/jdb
sudo update-alternatives --remove jdeprscan /opt/zulu/bin/jdeprscan
sudo update-alternatives --remove jdeps /opt/zulu/bin/jdeps
sudo update-alternatives --remove jfr /opt/zulu/bin/jfr
sudo update-alternatives --remove jhsdb /opt/zulu/bin/jhsdb
sudo update-alternatives --remove jimage /opt/zulu/bin/jimage
sudo update-alternatives --remove jinfo /opt/zulu/bin/jinfo
sudo update-alternatives --remove jlink /opt/zulu/bin/jlink
sudo update-alternatives --remove jmap /opt/zulu/bin/jmap
sudo update-alternatives --remove jmod /opt/zulu/bin/jmod
sudo update-alternatives --remove jpackage /opt/zulu/bin/jpackage
sudo update-alternatives --remove jps /opt/zulu/bin/jps
sudo update-alternatives --remove jrunscript /opt/zulu/bin/jrunscript
sudo update-alternatives --remove jshell /opt/zulu/bin/jshell
sudo update-alternatives --remove jstack /opt/zulu/bin/jstack
sudo update-alternatives --remove jstat /opt/zulu/bin/jstat
sudo update-alternatives --remove jstatd /opt/zulu/bin/jstatd
sudo update-alternatives --remove keytool /opt/zulu/bin/keytool
sudo update-alternatives --remove rmiregistry /opt/zulu/bin/rmiregistry
sudo update-alternatives --remove serialver /opt/zulu/bin/serialver
echo
echo "\e[93mEliminando Directorio"
echo "\e[0m"
sudo rm -r -f /opt/zulu
echo "\e[93mEliminando Enlaces de Azul Zulu OpenJDK"
echo
echo "\e[93mActualizando Base de Datos"
echo "\e[0m"
sudo updatedb
echo "\e[93mEliminación de Azul Zulu OpenJDK finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo
