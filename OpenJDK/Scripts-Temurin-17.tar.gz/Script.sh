#!/bin/sh
sudo mv Actualizar-Adoptium-Temurin.sh /usr/local/bin/actualizar-temurin
sudo mv Instalar-Adoptium-Temurin.sh /usr/local/bin/instalar-temurin
sudo mv Eliminar-Adoptium-Temurin.sh /usr/local/bin/eliminar-temurin
sudo chmod +x /usr/local/bin/actualizar-temurin
sudo chmod +x /usr/local/bin/instalar-temurin
sudo chmod +x /usr/local/bin/eliminar-temurin
cd /usr/local/bin
sudo chown root:root *
