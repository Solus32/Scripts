#!/bin/sh
echo
echo "\e[93mSe Eliminará Adoptium Temurin OpenJDK"
echo
echo "\e[93mEliminando Adoptium Temurin OpenJDK"
echo
echo "\e[93mEliminando Alternativas de Java"
echo
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo update-alternatives --remove jar /opt/temurin/bin/jar
sudo update-alternatives --remove jarsigner /opt/temurin/bin/jarsigner
sudo update-alternatives --remove java /opt/temurin/bin/java
sudo update-alternatives --remove javac /opt/temurin/bin/javac
sudo update-alternatives --remove javadoc /opt/temurin/bin/javadoc
sudo update-alternatives --remove javap /opt/temurin/bin/javap
sudo update-alternatives --remove jcmd /opt/temurin/bin/jcmd
sudo update-alternatives --remove jconsole /opt/temurin/bin/jconsole
sudo update-alternatives --remove jdb /opt/temurin/bin/jdb
sudo update-alternatives --remove jdeprscan /opt/temurin/bin/jdeprscan
sudo update-alternatives --remove jdeps /opt/temurin/bin/jdeps
sudo update-alternatives --remove jfr /opt/temurin/bin/jfr
sudo update-alternatives --remove jhsdb /opt/temurin/bin/jhsdb
sudo update-alternatives --remove jimage /opt/temurin/bin/jimage
sudo update-alternatives --remove jinfo /opt/temurin/bin/jinfo
sudo update-alternatives --remove jlink /opt/temurin/bin/jlink
sudo update-alternatives --remove jmap /opt/temurin/bin/jmap
sudo update-alternatives --remove jmod /opt/temurin/bin/jmod
sudo update-alternatives --remove jpackage /opt/temurin/bin/jpackage
sudo update-alternatives --remove jps /opt/temurin/bin/jps
sudo update-alternatives --remove jrunscript /opt/temurin/bin/jrunscript
sudo update-alternatives --remove jshell /opt/temurin/bin/jshell
sudo update-alternatives --remove jstack /opt/temurin/bin/jstack
sudo update-alternatives --remove jstat /opt/temurin/bin/jstat
sudo update-alternatives --remove jstatd /opt/temurin/bin/jstatd
sudo update-alternatives --remove keytool /opt/temurin/bin/keytool
sudo update-alternatives --remove rmiregistry /opt/temurin/bin/rmiregistry
sudo update-alternatives --remove serialver /opt/temurin/bin/serialver
echo
echo "\e[93mEliminando Directorio"
echo "\e[0m"
sudo rm -r -f /opt/temurin
echo "\e[93mEliminando Enlaces de Adoptium Temurin OpenJDK"
echo
echo "\e[93mActualizando Base de Datos"
echo "\e[0m"
sudo updatedb
echo "\e[93mEliminación de Adoptium Temurin OpenJDK finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo
