#!/bin/sh
echo "\e[93mSe instalara Adoptium Temurin OpenJDK"
sudo apt purge default-jre default-jdk openjdk* icedtea* gcj*
sudo apt autoremove
echo "\e[93mDescomprimiendo Adoptium Temurin OpenJDK"
echo "\e[0m"
cd ~/Descargas
tar -xvf OpenJDK*.tar.gz
rm OpenJDK*.tar.gz
mv jdk* temurin
echo "\e[91mSe requiere permisos root. Teclee su Contraseña."
echo "\e[93mCreando Directorio"
sudo mkdir -p /opt
echo "\e[93mMoviendo Carpeta a /opt/temurin"
echo "\e[0m"
sudo mv temurin /opt
sudo chown -R root:root /opt/temurin
echo "\e[93mActualizando Alternativas de Java"
echo "\e[0m"
sudo update-alternatives --install '/usr/bin/jar' 'jar' '/opt/temurin/bin/jar' 1
sudo update-alternatives --install '/usr/bin/jarsigner' 'jarsigner' '/opt/temurin/bin/jarsigner' 1
sudo update-alternatives --install '/usr/bin/java' 'java' '/opt/temurin/bin/java' 1
sudo update-alternatives --install '/usr/bin/javac' 'javac' '/opt/temurin/bin/javac' 1
sudo update-alternatives --install '/usr/bin/javadoc' 'javadoc' '/opt/temurin/bin/javadoc' 1
sudo update-alternatives --install '/usr/bin/javap' 'javap' '/opt/temurin/bin/javap' 1
sudo update-alternatives --install '/usr/bin/jcmd' 'jcmd' '/opt/temurin/bin/jcmd' 1
sudo update-alternatives --install '/usr/bin/jconsole' 'jconsole' '/opt/temurin/bin/jconsole' 1
sudo update-alternatives --install '/usr/bin/jdb' 'jdb' '/opt/temurin/bin/jdb' 1
sudo update-alternatives --install '/usr/bin/jdeprscan' 'jdeprscan' '/opt/temurin/bin/jdeprscan' 1
sudo update-alternatives --install '/usr/bin/jdeps' 'jdeps' '/opt/temurin/bin/jdeps' 1
sudo update-alternatives --install '/usr/bin/jfr' 'jfr' '/opt/temurin/bin/jfr' 1
sudo update-alternatives --install '/usr/bin/jhsdb' 'jhsdb' '/opt/temurin/bin/jhsdb' 1
sudo update-alternatives --install '/usr/bin/jimage' 'jimage' '/opt/temurin/bin/jimage' 1
sudo update-alternatives --install '/usr/bin/jinfo' 'jinfo' '/opt/temurin/bin/jinfo' 1
sudo update-alternatives --install '/usr/bin/jlink' 'jlink' '/opt/temurin/bin/jlink' 1
sudo update-alternatives --install '/usr/bin/jmap' 'jmap' '/opt/temurin/bin/jmap' 1
sudo update-alternatives --install '/usr/bin/jmod' 'jmod' '/opt/temurin/bin/jmod' 1
sudo update-alternatives --install '/usr/bin/jpackage' 'jpackage' '/opt/temurin/bin/jpackage' 1
sudo update-alternatives --install '/usr/bin/jps' 'jps' '/opt/temurin/bin/jps' 1
sudo update-alternatives --install '/usr/bin/jrunscript' 'jrunscript' '/opt/temurin/bin/jrunscript' 1
sudo update-alternatives --install '/usr/bin/jshell' 'jshell' '/opt/temurin/bin/jshell' 1
sudo update-alternatives --install '/usr/bin/jstack' 'jstack' '/opt/temurin/bin/jstack' 1
sudo update-alternatives --install '/usr/bin/jstat' 'jstat' '/opt/temurin/bin/jstat' 1
sudo update-alternatives --install '/usr/bin/jstatd' 'jstatd' '/opt/temurin/bin/jstatd' 1
sudo update-alternatives --install '/usr/bin/keytool' 'keytool' '/opt/temurin/bin/keytool' 1
sudo update-alternatives --install '/usr/bin/rmiregistry' 'rmiregistry' '/opt/temurin/bin/rmiregistry' 1
sudo update-alternatives --install '/usr/bin/serialver' 'serialver' '/opt/temurin/bin/serialver' 1
echo "\e[93mActualizando Base de Datos"
echo "\e[0m"
sudo updatedb
echo "\e[93mInstalacion de Adoptium Temurin OpenJDK finalizada"
echo "\e[93mQue tengas un bonito dia"
echo "\e[0m"
