#!/bin/sh
echo
echo "\e[93mSe Actualizará Adoptium Temurin OpenJDK"
echo
echo "\e[93mDescomprimiendo Adoptium Temurin OpenJDK"
echo "\e[0m"
cd ~/Descargas
tar -xvf OpenJDK*.tar.gz
rm OpenJDK*.tar.gz
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo rm -r -f /opt/temurin
echo "\e[93mActualizando Directorio"
echo "\e[0m"
mv jdk* temurin
echo "\e[93mMoviendo Carpeta a /opt/temurin"
echo "\e[0m"
sudo mv temurin /opt
sudo chown -R root:root /opt/temurin
echo "\e[93mActualización de Adoptium Temurin OpenJDK finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo
