#!/bin/bash
# Script created by Forrest to expand the roms file system to an external
# So folks will stop getting ripped off for bigger drives on ebay.
mkdir /home/pi/addonusb > /dev/null 2>&1
mkdir /home/pi/.work > /dev/null 2>&1
testdrive=`df |grep media |awk '{print $1 }'|wc -l`
if [ $testdrive -eq 0 ] ; then
echo "No se detecta una Unidad Externa. Saliendo."
sleep 5
exit
else
echo "Unidad Externa detectada. Realizando las pruebas para el Sistema de Archivos NTFS y el directorio de piroms."
sleep 5
fi

for EXTDR in `df |grep media |awk '{print $1 }'`; do
init_usb_type=`sudo blkid |grep "$EXTDR"|grep -Po 'TYPE="\K.*?(?=")'`
init_usb_filesystem=`sudo blkid |grep "$EXTDR"|awk '{print $1 }'| sed -r 's/(:)+$//'`
sudo umount $EXTDR
sudo mount -t  $init_usb_type $init_usb_filesystem /home/pi/addonusb
usb_path=`find "/home/pi/addonusb/" |grep piroms |head -1`

if [ ! -d "$usb_path" ]; then
    echo ""
    echo ""
    echo "No se pueden localizar el directorio de /piroms en esta unidad externa. Verificando otras particiones y puntos de montaje en esta unidad externa."
    echo ""
    echo ""
    echo ""
        sudo umount $init_usb_filesystem
    sleep 8
else
        usb_path=`find "/home/pi/addonusb/" |grep piroms |head -1`
                usb_dir=/home/pi/addonusb
fi
done

usb_designation=`df -T |grep $usb_dir |awk '{print $1 }'|awk -F'/' '{print $3 }'`
usb_mount=`df -T |grep $usb_dir |awk '{print $1 }'`
usb_filesystem=`sudo blkid |grep -w "$usb_mount"|grep -Po 'TYPE="\K.*?(?=")'`
usb_uuid=`ls -l /dev/disk/by-uuid/|grep $usb_designation|awk '{print $9 }'`
if [ "$usb_filesystem" != "ntfs" ] ; then
echo "Esta unidad externa no esta correctamente formateada. Debe ser formateada usando el sistema de archivos NTFS. Porfavor formatee a NTFS."
echo "Sistema de Archivos Fat vfat exfat no estan soportados en Linux"
sleep 10; exit
else echo "Verificando Unidad Externa. Correctamente formateada a NTFS"
sleep 5
fi

sudo grep -w UUID /etc/fstab > /dev/null 2>&1
if [ $? -eq 0 ] ; then
echo "Parece que ya tienes registrada una unidad externa. Solo una unidad externa esta soportada. Porfavor ejecuta "Remove Drive Expansion" en el Script del Menu de RetroPie antes de agregar una nueva unidad."
sleep 10
exit
else

echo "UUID=$usb_uuid  /home/pi/addonusb      $usb_filesystem    nofail,user,umask=0000  0       2" > /home/pi/.currentdrive
sudo sh -c 'cat /home/pi/.currentdrive >> /etc/fstab'
sudo umount $usb_mount
sudo mount -a
mkdir $usb_path/roms/
find "/home/pi/RetroPie/roms" -mindepth 1 -maxdepth 1 -type d -printf "$usb_path/roms/%f\n" | xargs mkdir -p 2>/dev/null || true
sleep 1
sudo runuser -l pi -c 'mv /home/pi/RetroPie/roms /home/pi/RetroPie/localroms/'
sudo runuser -l pi -c 'mkdir /home/pi/RetroPie/roms'
cd /etc/profile.d
sudo wget http://eazyhax.com/pitime/10-retropie.sh.exp
sudo mv /etc/profile.d/10-retropie.sh /etc/profile.d/10-retropie.sh.org
sudo cp /etc/profile.d/10-retropie.sh.exp /etc/profile.d/10-retropie.sh
sudo grep "avoid_warnings" /boot/config.txt > /dev/null 2>&1
if [ $? -eq 0 ] ; then
echo ""
else
sudo cp /boot/config.txt /boot/config.txt.bkup
sudo runuser -l root -c 'echo "avoid_warnings=2" >> /boot/config.txt'
fi
echo "La Unidad ha sido expandida y tu sistema se detendra. Desconecta tu unidad externa... Vuelve a conectarla a tu computadora. Carga los juegos después vuelve a conectar a tu RetroPie y reincia tu Raspberry Pi. Ya debes ver tus juegos agregados. Diviertete!!"
sleep 10
sudo halt
fi

