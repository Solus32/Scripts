#!/bin/bash
echo "Esto reseteara tus controles, reinicia Retropie despues"
sleep 5
echo "Vas a necesitar reconfigurar todos tus controles."
sleep 2
rm /opt/retropie/configs/all/retroarch-joypads/*
cd /home/pi/.emulationstation/
rm es_input.cfg
cd /home/pi/.emulationstation/; wget https://raw.githubusercontent.com/Solus32/RetroPie/master/es_input.cfg.bkup; cp es_input.cfg.bkup es_input.cfg
sudo reboot
exit

