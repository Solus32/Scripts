#!/bin/bash
echo "Esto reseteara tus controles, reinicia Retropie despues"
sleep 5
echo "Vas a necesitar reconfigurar todos tus controles."
sleep 2
rm /opt/retropie/configs/all/retroarch/autoconfig/*
cd /opt/retropie/configs/all/emulationstation/
rm es_input.cfg
wget https://raw.githubusercontent.com/Solus32/RetroPie/master/es_input.cfg.bkup; cp es_input.cfg.bkup es_input.cfg
systemctl reboot
exit

