#!/bin/bash
if [ ! -d /home/pi/RetroPie/localroms ]; then
    echo ""
    echo ""
    echo "No detecto que este Retropie haya sido expandido. Matando este script."
    echo ""
    echo ""
    sleep 5
else

sudo sed -i '/addon/d' /etc/fstab
sudo cp /etc/profile.d/10-retropie.sh.org /etc/profile.d/10-retropie.sh
unlink /home/pi/RetroPie/roms; sudo umount /home/pi/addonusb; sudo umount overlay; sudo umount /home/pi/RetroPie/roms;rm -r /home/pi/RetroPie/roms; mv /home/pi/RetroPie/localroms /home/pi/RetroPie/roms  > /dev/null 2>&1
systemctl reboot
fi
