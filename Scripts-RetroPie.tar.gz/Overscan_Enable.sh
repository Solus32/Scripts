#!/usr/bin/env bash
echo "Tu Retropie está a punto de reiniciarse para que la configuración surta efecto!"
sleep 5
sudo perl -p -i -e 's/disable_overscan=1/#disable_overscan=1/g' /boot/config.txt
sudo reboot
