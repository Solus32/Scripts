#!/bin/bash
sudo grep hdmi_force_edid_audio /boot/config.txt > /dev/null 2>&1
if [ $? -eq 0 ] ; then
echo "Los cambios en el Audio se realizaron. Si sigues sin tener sonido, entonces debe ser otro problema.."
sleep 4
echo "Por ahora revertiré los cambios ya que no te ayudaron."
sleep 5
sudo perl -p -i -e 's/hdmi_force_edid_audio=1/#dtoverlay=lirc-rpi/g' /boot/config.txt
sudo perl -p -i -e 's/hdmi_force_hotplug=1/#hdmi_force_hotplug=1/g' /boot/config.txt
sudo perl -p -i -e 's/hdmi_drive=2/#hdmi_drive=2/g' /boot/config.txt
else
echo "He escaneado el archivo de configuración y veo que la corrección de audio NO está en su lugar."
sleep 4
echo "Si esta solución no funciona, ejecute el script de nuevo para deshacer los cambios."
sleep 10
echo "Haré los cambios de configuración necesarios y reiniciaré tu Raspberry Pi"
sleep 5
sudo perl -p -i -e 's/#dtoverlay=lirc-rpi/hdmi_force_edid_audio=1/g' /boot/config.txt
sudo perl -p -i -e 's/#hdmi_force_hotplug=1/hdmi_force_hotplug=1/g' /boot/config.txt
sudo perl -p -i -e 's/#hdmi_drive=2/hdmi_drive=2/g' /boot/config.txt
sudo reboot
fi
