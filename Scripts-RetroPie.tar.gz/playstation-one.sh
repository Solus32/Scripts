#!/bin/bash
wget https://github.com/Solus32/RetroPie/raw/master/Sony_PlayStation_PSOne.mp4 /home/pi/RetroPie/splashscreens/video/Sony_PlayStation_PSOne.mp4
