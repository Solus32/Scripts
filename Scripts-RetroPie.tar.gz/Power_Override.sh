#!/bin/bash
sudo grep "avoid_warnings" /boot/config.txt > /dev/null 2>&1
if [ $? -eq 0 ] ; then
echo ""
else
sudo cp /boot/config.txt /boot/config.txt.bkup
sudo runuser -l root -c 'echo "avoid_warnings=2" >> /boot/config.txt'
fi
echo "Se han realizado cambios de configuración para anular las restricciones de energía del Raspberry Pi y tu sistema se reiniciará para que los cambios entren en vigencia. "
sleep 5
sudo reboot
