#!/bin/sh
sudo mv disable_expand_to_external_drive.sh /usr/local/bin/desactivar-unidad-externa
sudo mv enable_expand_to_external_drive.sh /usr/local/bin/activar-unidad-externa
sudo mv Disk_Space.sh /usr/local/bin/espacio-disco
sudo mv Kill_EmulationStation.sh /usr/local/bin/matar-emulationstation
sudo mv No_Audio_Fix.sh /usr/local/bin/no-audio-fix
sudo mv Overscan_Enable.sh /usr/local/bin/activar-overscan
sudo mv Overscan_Disable.sh /usr/local/bin/desactivar-overscan
sudo mv Power_Override.sh /usr/local/bin/eliminar-rayo
sudo mv Reset_Controllers.sh /usr/local/bin/reiniciar-controles
sudo mv Script-Logitech-Gamepad-F710.sh /usr/local/bin/logitech-gamepad
sudo mv playstation-one.sh /usr/local/bin/playstation-one
sudo chmod +x /usr/local/bin/desactivar-unidad-externa
sudo chmod +x /usr/local/bin/activar-unidad-externa
sudo chmod +x /usr/local/bin/espacio-disco
sudo chmod +x /usr/local/bin/matar-emulationstation
sudo chmod +x /usr/local/bin/no-audio-fix
sudo chmod +x /usr/local/bin/activar-overscan
sudo chmod +x /usr/local/bin/desactivar-overscan
sudo chmod +x /usr/local/bin/eliminar-rayo
sudo chmod +x /usr/local/bin/reiniciar-controles
sudo chmod +x /usr/local/bin/logitech-gamepad
sudo chmod +x /usr/local/bin/playstation-one
cd /usr/local/bin
sudo chown root:root *
