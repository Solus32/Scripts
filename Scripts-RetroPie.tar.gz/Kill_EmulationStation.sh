#!/bin/bash
killall emulationstation
exit
