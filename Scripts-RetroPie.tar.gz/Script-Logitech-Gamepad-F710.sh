#!/bin/bash
wget -c https://raw.githubusercontent.com/Solus32/RetroPie/master/Logitech%20Gamepad%20F710.cfg -O /opt/retropie/configs/all/retroarch/autoconfig/"Logitech Gamepad F710.cfg"
wget -c https://raw.githubusercontent.com/Solus32/RetroPie/master/es_input_Logitech_Gamepad_F710.cfg -O /opt/retropie/configs/all/emulationstation/es_input.cfg
