#!/bin/sh
sudo apt install -f
