#!/bin/sh
echo
echo "\e[93mInstalación de ADB y Fastboot de Android para Ubuntu/Debian"
echo
echo "\e[93mDescomprimiendo archivos"
echo "\e[0m"
cd ~/Descargas
tar -xvzf platform-tools-rev*.tar.gz
echo
echo "\e[93mMoviendo archivos"
echo
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo mv adb /usr/local/bin
sudo mv fastboot /usr/local/bin
echo
echo "\e[93mOtorgando permisos necesarios"
echo "\e[0m"
sudo chmod u=rw,go=r /usr/local/bin/adb 
sudo chmod u=rw,go=r /usr/local/bin/fastboot
sudo chmod +x /usr/local/bin/adb
sudo chmod +x /usr/local/bin/fastboot
rm platform-tools-rev*.tar.gz
cd /usr/local/bin
sudo chown root:root *
echo
echo "\e[93mInstalación finalizada ya puedes usar adb y fastboot"
echo
echo "\e[93mQue tengas un bonito dia"
echo
