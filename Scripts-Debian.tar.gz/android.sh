#!/bin/sh
echo "Instalacion de ADB y Fastboot de Android para Ubuntu/Debian"
echo "Descomprimiendo archivos"
cd ~/Descargas
tar -xvzf platform-tools-rev*.tar.gz
echo "Se requiere permisos root. Teclee su Contraseña."
echo "Moviendo archivos"
sudo mv adb /usr/local/bin
sudo mv fastboot /usr/local/bin
echo "Otorgando permisos necesarios"
sudo chmod u=rw,go=r /usr/local/bin/adb 
sudo chmod u=rw,go=r /usr/local/bin/fastboot
sudo chmod +x /usr/local/bin/adb
sudo chmod +x /usr/local/bin/fastboot
rm platform-tools-rev*.tar.gz
cd /usr/local/bin
sudo chown root:root *
echo "Instalacion finalizada ya puedes usar adb y fastboot"
echo "Que tengas un bonito dia"
