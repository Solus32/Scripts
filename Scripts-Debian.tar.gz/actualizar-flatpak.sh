#!/bin/bash
flatpak update
