#!/bin/sh
echo
echo "\e[93mSe Actualizará los Archivos Flatpak"
echo "\e[0m"
flatpak update
echo
echo "\e[93mActualización de los Archivos Flatpak Finalizada"
echo
