#!/bin/sh
dropbox stop && dbus-launch dropbox start
