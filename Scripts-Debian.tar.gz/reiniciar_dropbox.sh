#!/bin/bash
dropbox stop && dbus-launch dropbox start
