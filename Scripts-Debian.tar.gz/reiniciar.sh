#!/bin/sh
echo
echo "\e[93mSe Reiniciará la Computadora en 3 Segundos"
echo "\e[0m"
sync
sleep 3
systemctl reboot
