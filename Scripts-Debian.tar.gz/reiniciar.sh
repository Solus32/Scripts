#!/bin/bash
systemctl reboot