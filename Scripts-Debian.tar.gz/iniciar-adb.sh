#!/bin/bash
sudo adb start-server
