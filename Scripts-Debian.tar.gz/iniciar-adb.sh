#!/bin/sh
echo
echo "\e[93mIniciando ADB"
echo "\e[0m"
adb start-server
echo
echo "\e[93mADB Iniciado"
echo
