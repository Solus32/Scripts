#!/bin/bash
adb start-server
