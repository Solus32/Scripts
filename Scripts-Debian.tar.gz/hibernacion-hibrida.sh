#!/bin/bash
systemctl hybrid-sleep