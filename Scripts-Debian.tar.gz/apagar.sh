#!/bin/sh
echo
echo "\e[93mSe Apagará la Computadora en 3 Segundos"
echo "\e[0m"
sync
sleep 3
systemctl poweroff
