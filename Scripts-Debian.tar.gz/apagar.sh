#!/bin/bash
systemctl poweroff