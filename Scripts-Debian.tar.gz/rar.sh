#!/bin/sh
echo "Se Instalara RAR para Linux"
echo "Descompresion de archivos comprimidos"
cd ~/Descargas
tar -xvzf rarlinux-*.tar.gz
cd rar
sudo make install
cd ~/Descargas
rm -r rar
rm rarlinux-*.tar.gz
