#!/bin/sh
echo
echo "\e[93mSe Instalará RAR para Linux"
echo
echo "\e[93mDescompresión de archivos comprimidos"
echo "\e[0m"
cd ~/Descargas
tar -xvzf rarlinux-*.tar.gz
cd rar
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo make install
cd ~/Descargas
rm -r rar
rm rarlinux-*.tar.gz
echo
echo "\e[93mInstalación Finalizada"
echo
