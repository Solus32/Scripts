#!/bin/sh
echo "\e[93mSe Instalara RAR para Linux"
echo
echo "\e[93mDescompresión de archivos comprimidos"
echo
echo "\e[0m"
cd ~/Descargas
tar -xvzf rarlinux-*.tar.gz
cd rar
echo "\e[91mTeclea tu Contraseña"
echo
echo "\e[0m"
sudo make install
cd ~/Descargas
rm -r rar
rm rarlinux-*.tar.gz
