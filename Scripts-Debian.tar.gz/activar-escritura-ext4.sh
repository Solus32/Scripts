#!/bin/sh
echo
echo "\e[93mActivando Escritura del Sistema de Archivos en Linux"
echo "\e[0m"
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo chown -R $USER:$USER /media/$USER/*
echo
echo "\e[93mActivada la Escritura del Sistema Archivos en Linux"
echo
