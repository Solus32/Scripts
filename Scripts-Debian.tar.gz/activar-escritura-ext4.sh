#!/bin/bash
sudo chown -R $USER:$USER /media/$USER/*
