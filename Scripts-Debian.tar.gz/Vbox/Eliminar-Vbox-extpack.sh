#!/bin/sh
cd ~/.config/VirtualBox
rm *.vbox-extpack
