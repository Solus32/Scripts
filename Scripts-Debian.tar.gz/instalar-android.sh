#!/bin/sh
echo
echo "\e[93mInstalación de ADB y Fastboot de Android para Ubuntu/Debian"
echo
echo "\e[93mDescargando y Descomprimiendo archivos"
echo "\e[0m"
cd ~/Descargas
wget https://dl.google.com/android/repository/platform-tools-latest-linux.zip
unzip platform-tools-latest-linux.zip
cd platform-tools
echo
echo "\e[93mMoviendo archivos"
echo
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo mv adb /usr/local/bin
sudo mv fastboot /usr/local/bin
echo "\e[93mOtorgando permisos necesarios"
echo "\e[0m"
sudo chmod u=rw,go=r /usr/local/bin/adb
sudo chmod u=rw,go=r /usr/local/bin/fastboot
sudo chmod +x /usr/local/bin/adb
sudo chmod +x /usr/local/bin/fastboot
cd ~/Descargas
rm platform-tools-latest-linux.zip
rm -r platform-tools
cd /usr/local/bin
sudo chown root:root *
echo "\e[93mBorrando archivos descargados y carpetas temporales"
echo
echo "\e[93mInstalación finalizada ya puedes usar adb y fastboot"
echo
echo "\e[93mQue tengas un bonito dia"
echo
