#!/bin/sh
echo
echo "\e[93mSe Descomprimirán los archivos tar.gz"
echo "\e[0m"
tar -xvzf *.tar.gz
echo
echo "\e[93mDescompresión Terminada"
echo
