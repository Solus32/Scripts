#!/bin/sh
tar -xvzf *.tar.gz
