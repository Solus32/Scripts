#!/bin/sh
sudo pip install setuptools
sudo pip install pip
sudo pip install cfscrape
