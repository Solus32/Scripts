#!/bin/sh
echo
echo "\e[93mSe Actualizará los Paquetes Snap"
echo "\e[0m"
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo snap refresh 
echo
echo "\e[93mActualización de los Paquetes Snap Finalizada"
echo

