#!/bin/sh
sudo apt clean
sudo apt autoclean
