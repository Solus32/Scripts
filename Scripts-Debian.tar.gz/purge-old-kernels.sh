#!/bin/sh
echo
echo "\e[93mDesinstalando Kernels Antiguos de Linux"
echo "\e[0m"
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo apt purge $(dpkg-query -W -f'${Package}\n' 'linux-*' | sed -nr 's/.*-([0-9]+(\.[0-9]+){2}-[^-]+).*/\1 &/p' | sort -k 1,1V | awk '($1==c){exit} {print $2}' c=$(uname -r | cut -f1,2 -d-))
sudo update-grub
echo
echo "\e[93mDesinstalación de Kernels Antiguos Terminada"
echo
