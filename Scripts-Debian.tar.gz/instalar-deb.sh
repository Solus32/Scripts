#!/bin/sh
sudo dpkg -i *.deb

