#!/bin/sh
echo
echo "\e[93mInstalando Archivos .deb"
echo "\e[0m"
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo dpkg -i *.deb
echo
echo "\e[93mInstalación Terminada"
echo

