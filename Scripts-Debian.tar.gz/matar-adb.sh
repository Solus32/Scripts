#!/bin/bash
adb kill-server
