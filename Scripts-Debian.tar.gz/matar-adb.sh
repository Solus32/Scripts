#!/bin/sh
echo
echo "\e[93mMatando ADB"
echo "\e[0m"
adb kill-server
echo "\e[93mProceso Terminado"
echo
