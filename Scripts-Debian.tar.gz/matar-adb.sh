#!/bin/bash
sudo adb kill-server
