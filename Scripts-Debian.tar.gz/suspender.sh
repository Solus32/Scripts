#!/bin/sh
echo
echo "\e[93mSe Suspenderá la Computadora en 3 Segundos"
echo "\e[0m"
sleep 3
systemctl suspend
