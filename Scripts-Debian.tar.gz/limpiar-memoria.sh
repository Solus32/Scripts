#!/bin/sh
xsel -bc
