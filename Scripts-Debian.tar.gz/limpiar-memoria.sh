#!/bin/sh
echo
echo "\e[93mLimpiando Memoria"
echo "\e[0m"
xsel -bc
echo "\e[93mLimpieza de Memoria Completada"
echo
