#!/bin/sh
echo
echo "\e[93mSe Descomprimirán los archivos tar.bz2"
echo "\e[0m"
tar -xvjf *.tar.bz2
echo "\e[93mDescompresión Terminada"
echo
