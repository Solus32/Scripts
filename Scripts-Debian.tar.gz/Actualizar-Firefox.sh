#!/bin/sh
echo "Se Actualizara Mozilla Firefox"
cd ~/Descargas
echo "Descomprimiendo Firefox"
tar -jxvf firefox*.tar.bz2
echo "Eliminado antiguos archivos de Firefox en /opt/firefox"
echo "Se requiere permisos root. Teclee su Contraseña."
sudo rm -r /opt/firefox
echo "Moviendo archivos"
sudo mv firefox /opt
cd /opt
sudo chown -R $USER:$USER firefox
cd ~/Descargas
rm firefox*.tar.bz2
echo "Actualizacion de Mozilla Firefox Finalizada"
echo "Que tengas un bonito dia"
