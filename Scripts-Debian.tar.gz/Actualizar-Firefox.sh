#!/bin/sh
echo
echo "\e[93mSe Actualizará Mozilla Firefox"
echo "\e[0m"
cd ~/Descargas
echo "\e[93mDescomprimiendo Firefox"
echo "\e[0m"
tar -jxvf firefox*.tar.bz2
echo
echo "\e[93mEliminado antiguos archivos de Firefox en /opt/firefox"
echo
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo rm -r /opt/firefox
echo
echo "\e[93mMoviendo archivos"
echo "\e[0m"
sudo mv firefox /opt
cd /opt
sudo chown -R $USER:$USER firefox
cd ~/Descargas
rm firefox*.tar.bz2
echo "\e[93mActualización de Mozilla Firefox Finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo
