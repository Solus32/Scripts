#!/bin/sh
sudo pip install -U setuptools
sudo pip install -U pip
sudo pip install -U cfscrape
