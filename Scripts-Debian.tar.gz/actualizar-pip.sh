#!/bin/sh
sudo pip install setuptools -U
sudo pip install pip -U
sudo pip install cfscrape -U
