#!/bin/sh
echo
echo "\e[93mDesactivando RedShift"
echo "\e[0m"
redshift -x
echo
echo "\e[93mRedShift Desactivado"
echo
