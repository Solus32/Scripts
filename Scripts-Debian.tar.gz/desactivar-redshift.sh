#!/bin/sh
redshift -x
