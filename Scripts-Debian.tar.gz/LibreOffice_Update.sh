#!/bin/sh
echo
echo "\e[93mSe Actualizará LibreOffice"
echo
echo "\e[93mDescompresión de archivos comprimidos para Debian"
echo "\e[0m"
cd ~/Descargas
tar -xvzf LibreOffice_*_Linux_*_deb.tar.gz
tar -xvzf LibreOffice_*_Linux_*_deb_langpack_es.tar.gz
tar -xvzf LibreOffice_*_Linux_*_deb_helppack_es.tar.gz
echo
echo "\e[93mExtracción de archivos comprimidos finalizada"
echo
echo "\e[93mActualizando LibreOffice"
echo
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
cd LibreOffice_*_Linux_*_deb/DEBS
sudo dpkg -i *.deb
cd ~/Descargas
cd LibreOffice_*_Linux_*_deb_langpack_es/DEBS
sudo dpkg -i *.deb
cd ~/Descargas
cd LibreOffice_*_Linux_*_deb_helppack_es/DEBS
sudo dpkg -i *.deb
cd ~/Descargas
rm -r LibreOffice_*_Linux_*_deb
rm -r LibreOffice_*_Linux_*_deb_langpack_es
rm -r LibreOffice_*_Linux_*_deb_helppack_es
rm LibreOffice_*_Linux_*_deb.tar.gz
rm LibreOffice_*_Linux_*_deb_langpack_es.tar.gz
rm LibreOffice_*_Linux_*_deb_helppack_es.tar.gz
echo
echo "\e[93mActualización de LibreOffice finalizada"
echo
echo "\e[93mQue tengas un bonito día"
echo

