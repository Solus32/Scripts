#!/bin/sh
echo "Se Actualizara LibreOffice"
echo "Descompresion de archivos comprimidos para Debian"
cd ~/Descargas
tar -xvzf LibreOffice_*_Linux_*_deb.tar.gz
tar -xvzf LibreOffice_*_Linux_*_deb_langpack_es.tar.gz
tar -xvzf LibreOffice_*_Linux_*_deb_helppack_es.tar.gz
echo "Extraccion de archivos comprimidos finalizada"
echo "Actualizando LibreOffice"
echo "Se requiere permisos root. Teclee su Contraseña."
cd LibreOffice_*_Linux_*_deb/DEBS
sudo dpkg -i *.deb
cd ~/Descargas
cd LibreOffice_*_Linux_*_deb_langpack_es/DEBS
sudo dpkg -i *.deb
cd ~/Descargas
cd LibreOffice_*_Linux_*_deb_helppack_es/DEBS
sudo dpkg -i *.deb
cd ~/Descargas
rm -r LibreOffice_*_Linux_*_deb
rm -r LibreOffice_*_Linux_*_deb_langpack_es
rm -r LibreOffice_*_Linux_*_deb_helppack_es
rm LibreOffice_*_Linux_*_deb.tar.gz
rm LibreOffice_*_Linux_*_deb_langpack_es.tar.gz
rm LibreOffice_*_Linux_*_deb_helppack_es.tar.gz
echo "Actualizacion de LibreOffice finalizada"
echo "Que tengas un bonito dia"

