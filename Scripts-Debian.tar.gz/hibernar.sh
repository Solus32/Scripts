#!/bin/bash
systemctl hibernate