#!/bin/sh
cd ~/Descargas
tar -xf 7z*-linux-*.tar.xz
rm -r MANUAL
rm History.txt
rm License.txt
rm readme.txt
rm 7zzs
rm 7z*-linux-*.tar.xz
sudo mv 7zz /usr/local/bin/7zz
sudo chmod +x /usr/local/bin/7zz
cd /usr/local/bin
sudo chown root:root *

