#!/bin/sh
echo
echo "\e[93mSe Actualizará el Navegador Tor"
echo "\e[0m"
cd ~/Descargas
echo "\e[93mDescomprimiendo Tor"
echo "\e[0m"
tar -xf tor-browser-linux64-*.tar.xz
rm tor-browser-linux64-*.tar.xz
cd tor-browser_*
mv Browser tor
echo "\e[93mEliminado antiguos archivos de Tor en /opt/tor"
echo
echo "\e[91mSe requiere permisos root. Teclee su Contraseña."
echo "\e[0m"
sudo rm -r /opt/tor
echo "\e[93mMoviendo archivos"
sudo mv tor /opt
echo
echo "\e[93mOtorgando Permisos Necesarios"
cd /opt
sudo chown -R $USER:$USER tor
cd ~/Descargas
rm -r tor-browser_*
echo
echo "\e[93mActualización del Navegador Tor Finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo
