#!/bin/sh
redshift -O 3500
