#!/bin/sh
echo
echo "\e[93mActivando RedShift Modo Noche"
echo "\e[0m"
redshift -O 3500
echo
echo "\e[93mRedShift Modo Noche Activado"
echo
