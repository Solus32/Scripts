#!/bin/sh
echo
echo "\e[93mSe Actualizará Mozilla Thunderbird"
echo "\e[0m"
cd ~/Descargas
echo "\e[93mDescomprimiendo Thunderbird"
echo "\e[0m"
tar -jxvf thunderbird*.tar.bz2
echo
echo "\e[93mEliminado antiguos archivos de Thunderbird en /opt/thunderbird"
echo
echo "\e[91mSe necesita permisos Administrativos. Teclea tu Contraseña."
echo "\e[0m"
sudo rm -r /opt/thunderbird
echo
echo "\e[93mMoviendo archivos"
echo "\e[0m"
sudo mv thunderbird /opt
cd /opt
sudo chown -R $USER:$USER thunderbird
cd ~/Descargas
rm thunderbird*.tar.bz2
echo "\e[93mActualización de Mozilla Thunderbird Finalizada"
echo
echo "\e[93mQue tengas un bonito dia"
echo
