#!/bin/sh
echo
echo "\e[93mActivando RedShift Modo Día"
echo "\e[0m"
redshift -O 5500
echo
echo "\e[93mRedShift Modo Día Activado"
echo
