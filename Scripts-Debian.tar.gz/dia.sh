#!/bin/sh
redshift -O 5500
