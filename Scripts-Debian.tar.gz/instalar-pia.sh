#!/bin/sh
cd ~/Descargas
tar -xzf pia-v*-installer-linux.tar.gz
./pia-v*-installer-linux.sh
rm pia*
