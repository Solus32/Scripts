#!/bin/sh
echo
echo "\e[93mInstalando Private Internet Access VPN (PIA)"
echo "\e[0m"
cd ~/Descargas
tar -xzf pia-v*-installer-linux.tar.gz
./pia-v*-installer-linux.sh
rm pia*
echo "\e[93mInstalación Terminada"
echo
