#!/bin/sh
echo
echo "\e[93mInstalando Private Internet Access VPN (PIA)"
echo "\e[0m"
cd ~/Descargas
sh pia-linux-*-*.run
rm pia*
echo "\e[93mInstalación Terminada"
echo
