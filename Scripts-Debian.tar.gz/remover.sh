#!/bin/sh
sudo apt autoremove
